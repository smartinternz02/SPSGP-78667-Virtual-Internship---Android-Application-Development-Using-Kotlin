Sports App
===================================

Starter code for Android Basics codelab - Adaptive Layouts

Sports app is a basic app to introduce beginner students to adaptive layouts. This app consists of
two fragments: a sports topics list and a details screen. The details screen displays placeholder
text for the sports news.


Used in the [Android Basics with Kotlin](https://developer.android.com/courses/android-basics-kotlin/course) course.


Pre-requisites
--------------

You need to know:
- Knowledge about Fragments.
- Basics of Navigation


Getting Started
---------------

1. Download and run the app.
