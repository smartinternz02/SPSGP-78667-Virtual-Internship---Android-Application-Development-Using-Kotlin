package com.sritikamanjrekar.smartbridgeinternshippractice

import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatActivity

private const val TAG = "MainActivity"
class Debugging : AppCompatActivity() {


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_debugging)
        logging()
    }

    fun logging() {

            Log.e(TAG, "ERROR: a serious error like an app crash")
            Log.w(TAG, "WARN: warns about the potential for serious errors")
            Log.i(TAG, "INFO: reporting technical information, such as an operation succeeding")
            Log.d(TAG, "DEBUG: reporting technical information useful for debugging")
            Log.v(TAG, "VERBOSE: more verbose than DEBUG logs")

    }
}