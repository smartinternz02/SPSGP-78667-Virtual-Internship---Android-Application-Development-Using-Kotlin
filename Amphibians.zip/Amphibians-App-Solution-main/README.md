Amphibians - Solution
==================================

Solution code for the fourth independent project for Android Basics in Kotlin.

You can check your solution with the solutions provided

Code passes all the tests
